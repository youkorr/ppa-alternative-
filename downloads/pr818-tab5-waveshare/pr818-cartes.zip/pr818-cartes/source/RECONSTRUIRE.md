# Reconstruction des firmwares

Utiliser un terminal **ESP-IDF v5.5.6** avec Python 3.12+, Git et les outils
ESP32-P4 installés. Les dépendances exactes de chaque binaire livré se trouvent
dans son `dependencies.lock` (dont LVGL 9.6.0).

```sh
git clone --no-checkout https://github.com/youkorr/esp-iot-solution eis
git -C eis fetch origin ba1ed66c40c840cd1b2dbe9062760c2c86262b5a 7965432ed3220ab29a2b44c84d78f341d4185224
git clone https://github.com/youkorr/ppa-alternative- fixtures
python source/prepare.py --repo eis --fixtures fixtures --out essai --board tab5 --revision before
```

Le script extrait une copie isolée des composants de la révision demandée. Il
ne modifie aucun de ces deux dépôts. Les adaptations de carte sont celles du
commit `6cf0eed1277032489fd0281890b9a326c93f063f` de `ppa-alternative-`.
`--board waveshare-7b` prépare l’autre carte ; `--revision after` sélectionne la
mise à jour. Le SDK et tous les réglages de performance doivent rester identiques
entre les comparaisons.

Depuis `essai/components/display/tools/esp_lvgl_adapter/test_apps/lvgl9` :

```sh
idf.py -B build -D SDKCONFIG_DEFAULTS=sdkconfig.bench -D IDF_TARGET=esp32p4 build
idf.py -B build -p COM5 flash monitor
```

Utiliser un dossier `essai` neuf pour chaque carte/version lors d’une
reconstruction manuelle, afin de ne pas conserver un `sdkconfig` d’un autre
essai. Pour une reconstruction strictement figée, recopier le `dependencies.lock`
du firmware correspondant dans le dossier de l’application avant sa première
configuration. Les chemins d’override sont relatifs à la même arborescence.

Le banc est ajouté au fichier de tests officiel, utilise son initialisation
et son arrêt de l’adaptateur, puis lance uniquement `PR818 board comparison`.
Le rendu et le backend PPA sont ceux des commits indiqués, sans modification
de leur algorithme. La configuration de carte, le fond RGB565 déterministe et
la logique de mesure sont partagés entre `before` et `after`.

La version `after` appelle les API internes du cache sous le verrou LVGL pour
comparer les budgets 0 et 4 Mio dans le même firmware. L’option Kconfig du cache
reste à sa valeur par défaut 0 : le budget non nul est propre à la phase du banc.

Les sources du projet et du banc conservent leurs licences MIT/Apache-2.0/CC0
dans leurs en-têtes ; les dépendances sont celles d’ESP-IDF et du registre
Espressif. Le pilote Tab5 et sa table d’initialisation proviennent de l’adaptation
Apache-2.0 déjà présente dans `ppa-alternative-`.
