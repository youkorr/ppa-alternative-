# SPDX-FileCopyrightText: 2026 youkorr
# SPDX-License-Identifier: MIT
"""Flash a supplied ESP32-P4 benchmark and optionally save the current flash."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('board', choices=['tab5', 'waveshare-7b'])
    parser.add_argument('revision', choices=['before', 'after_v2'])
    parser.add_argument('--port', help='COM5, /dev/ttyACM0, etc.')
    parser.add_argument('--baud', default='460800')
    parser.add_argument('--backup', type=Path, help='Save the complete current flash before writing')
    parser.add_argument('--check-only', action='store_true', help='Verify hashes without accessing a board')
    parser.add_argument('--log', type=Path, help='Capture the automatic benchmark after flashing (115200 baud)')
    args = parser.parse_args()
    folder = ROOT / 'firmwares' / f'{args.board}-{args.revision}'
    meta = json.loads((folder / 'manifest.json').read_text())
    binary = folder / 'firmware.bin'
    if hashlib.sha256(binary.read_bytes()).hexdigest() != meta['firmware_sha256']:
        raise SystemExit('Empreinte du firmware incorrecte : extraire de nouveau le ZIP.')
    print(f"{args.board} / {args.revision} / {meta['commit']} : SHA256 correct", flush=True)
    if args.check_only:
        return
    if not args.port:
        parser.error('--port est requis pour flasher')
    if args.log and args.log.exists():
        parser.error('Le journal existe déjà ; choisir un autre nom avec --log')
    common = [sys.executable, '-m', 'esptool', '--chip', 'esp32p4', '--port', args.port, '--baud', args.baud]
    if args.backup:
        if args.backup.exists():
            raise SystemExit('Le fichier de sauvegarde existe déjà ; choisir un autre nom.')
        megabytes = 16 if args.board == 'tab5' else 32
        subprocess.run(common + ['read-flash', '0x0', hex(megabytes * 1024 * 1024), str(args.backup)], check=True)
    print('Écriture du banc autonome sur le P4 ; aucun identifiant Wi-Fi requis.', flush=True)
    subprocess.run(common + ['write-flash', '0x0', str(binary)], check=True)
    if args.log:
        capture(args.port, args.log)


def capture(port, output):
    import serial
    until = time.monotonic() + 360
    pending = b''
    saw_start = False
    with output.open('x', encoding='utf-8') as log:
        while time.monotonic() < until:
            try:
                connection = serial.Serial(port=None, baudrate=115200, timeout=1)
                connection.dtr = connection.rts = False
                connection.port = port
                connection.open()
                with connection:
                    while time.monotonic() < until:
                        pending += connection.read(4096)
                        while b'\n' in pending:
                            raw, pending = pending.split(b'\n', 1)
                            line = raw.decode('utf-8', errors='replace').rstrip('\r')
                            print(line, flush=True)
                            log.write(line + '\n')
                            log.flush()
                            saw_start |= 'PR818_START ' in line
                            if 'PR818_DONE' in line:
                                if not saw_start:
                                    raise SystemExit('Début du test manquant dans le journal ; refaire une capture complète.')
                                print(f'Journal enregistré : {output}', flush=True)
                                return
            except serial.SerialException:
                # USB Serial/JTAG may disappear briefly during the final reset.
                time.sleep(1)
    raise SystemExit(f'Délai dépassé ; journal partiel conservé dans {output}.')


if __name__ == '__main__':
    main()
