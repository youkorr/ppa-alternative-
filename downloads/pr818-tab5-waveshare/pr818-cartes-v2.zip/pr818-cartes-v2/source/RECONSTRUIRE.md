# Reconstruction des firmwares

Utiliser un terminal **ESP-IDF v5.5.6** avec Python 3.12+, Git et les outils
ESP32-P4 installés. Les dépendances exactes de chaque binaire livré se trouvent
dans son `dependencies.lock` (dont LVGL 9.6.0).

```sh
git clone --no-checkout https://github.com/youkorr/esp-iot-solution eis
git -C eis fetch origin ba1ed66c40c840cd1b2dbe9062760c2c86262b5a 7965432ed3220ab29a2b44c84d78f341d4185224 9db972e7008d4c5adab0fde59dc3b0b1343dac4c
git clone https://github.com/youkorr/ppa-alternative- fixtures
python source/prepare.py --repo eis --fixtures fixtures --out essai --board tab5 --revision before
```

Le script extrait une copie isolée des composants de la révision demandée. Il
ne modifie aucun de ces deux dépôts. Les adaptations de carte sont celles du
commit `6cf0eed1277032489fd0281890b9a326c93f063f` de `ppa-alternative-`.
`--board waveshare-7b` prépare l’autre carte ; `--revision after_v2` sélectionne les correctifs après les premiers essais.
`--revision after` conserve l’ancienne mise à jour pour reproduction historique. Le SDK et tous les réglages de performance doivent rester identiques
entre les comparaisons.

Depuis `essai/components/display/tools/esp_lvgl_adapter/test_apps/lvgl9` :

```sh
idf.py -B build -D SDKCONFIG_DEFAULTS=sdkconfig.bench -D IDF_TARGET=esp32p4 build
idf.py -B build -p COM5 flash monitor
```

Utiliser un dossier `essai` neuf pour chaque carte/version lors d’une
reconstruction manuelle, afin de ne pas conserver un `sdkconfig` d’un autre
essai. Pour une reconstruction strictement figée, recopier le `dependencies.lock`
du firmware correspondant dans le dossier de l’application avant sa première
configuration. Les chemins d’override sont relatifs à la même arborescence.

Le banc est ajouté au fichier de tests officiel, utilise son initialisation
et son arrêt de l’adaptateur, puis lance `PR818 board comparison` et, sur la V2, 16 tests de cycle de vie.
Le rendu et le backend PPA sont ceux des commits indiqués, sans modification
de leur algorithme. La configuration de carte, le fond RGB565 déterministe et
la logique de mesure sont partagés entre `before` et `after`.

Les versions `after` et `after_v2` appellent les API internes du cache sous le verrou LVGL pour
comparer les budgets 0 et 4 Mio dans le même firmware. L’option Kconfig du cache
reste à sa valeur par défaut 0 : le budget non nul est propre à la phase du banc.

Les sources du projet et du banc conservent leurs licences MIT/Apache-2.0/CC0
dans leurs en-têtes ; les dépendances sont celles d’ESP-IDF et du registre
Espressif. Le pilote Tab5 et sa table d’initialisation proviennent de l’adaptation
Apache-2.0 déjà présente dans `ppa-alternative-`.

La V2 lance 16 tests `adapter render threads can be stopped repeatedly` après
les mesures et exige leurs PASS avant la fin du journal. La correction du backend
LVGL est appliquée par le CMake du composant et reste conditionnée à
`ESP_LVGL_ADAPTER_ROTATE_IN_DRAW`. Les dépendances téléchargées doivent être
neuves pour reconstruire une ancienne version, car les hooks peuvent modifier
le backend dans un ancien dossier `managed_components`.
